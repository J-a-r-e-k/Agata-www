const burger = document.querySelector('div.burger');
const nav = document.querySelector('nav');
const navUl = document.querySelector('nav ul');
const iconBurger = document.querySelector('.fa-bars');
const iconX = document.querySelector('.fa-circle-xmark');

const btnBio = document.querySelector('.btn_bio');
const bio = document.querySelector('div.bio');
const btnBioX = document.querySelector('div.bio i');

const btnNav = document.querySelectorAll('nav ul li'); // Pobiera wszystkie li z nav
let navHaight = document.querySelector('nav').offsetHeight; // wysokońć wysokości NAV
// od jakiej wysokości zaczyna sie element ... //
const aboutMe = document.querySelector('.aboutMe').offsetTop;
const cooperationMe = document.querySelector('.cooperationMe').offsetTop;
const you = document.querySelector('.you').offsetTop;
const recruitment = document.querySelector('.recruitment').offsetTop;
const talkMe = document.querySelector('.talkMe').offsetTop;
const blog = document.querySelector('.blog').offsetTop;

// Włączenie wyłączenie nav
burger.addEventListener('click', function () {
  navUl.classList.toggle('activeBurger');
});

// włączenie Bio
btnBio.addEventListener('click', function () {
  bio.classList.add('activeBio');
});
// wyłączenie Bio
btnBioX.addEventListener('click', function () {
  bio.classList.remove('activeBio');
});

// Kliknięcie na element nawigacji

btnNav.forEach((li) => {
  li.addEventListener('click', (e) => {
    a = e.target.classList; // który elemetn został kliknięty w nav
    if (a == 'navAboutMe') {
      window.scrollTo(0, 0);
    } else if (a == 'navCooperationMe') {
      window.scrollTo(0, cooperationMe - navHaight);
    } else if (a == 'navYou') {
      window.scrollTo(0, you - navHaight);
    } else if (a == 'navRecruitment') {
      window.scrollTo(0, recruitment - navHaight);
    } else if (a == 'navTalkMe') {
      window.scrollTo(0, talkMe - navHaight);
    } else if (a == 'navBlog') {
      window.scrollTo(0, blog - navHaight);
    }
    navUl.classList.remove('activeBurger');
  });
});
btnNav[0].style.fontWeight = 'bold'; // po wczytaniu strony od razu Bold na 1 elemencie
let circleBold;
const boldScroll = (e) => {
  const topY = scrollY;
  //Tło nav
  nav.style.backgroundColor = `rgb(248, 248, 248)`; // Ciemne
  navUl.style.backgroundColor = `rgb(248, 248, 248)`; // jasny
  btnNav.forEach((circleBold) => (circleBold.style.fontWeight = '')); // Kasowanie Bold w nav po kadym kliknięciu
  // dodawanie Bold w miejscu którym jesteś
  if (topY >= 0 && topY < cooperationMe - navHaight) {
    btnNav[0].style.fontWeight = 'bold';
  } else if (topY >= cooperationMe - navHaight && topY < you - navHaight) {
    btnNav[1].style.fontWeight = 'bold';
  } else if (topY >= you - navHaight && topY < recruitment - navHaight) {
    btnNav[2].style.fontWeight = 'bold';
  } else if (topY >= recruitment - navHaight && topY < talkMe - navHaight) {
    btnNav[3].style.fontWeight = 'bold';
  } else if (topY >= talkMe - navHaight && topY < blog - navHaight) {
    btnNav[4].style.fontWeight = 'bold';
  } else if (topY >= blog - navHaight && topY < document.body.offsetHeight) {
    btnNav[5].style.fontWeight = 'bold';
  }
  // Kolor tła Nav

  if (topY > aboutMe - navHaight) {
    nav.style.backgroundColor = `rgb(217, 217, 217)`; //Ciemny
    navUl.style.backgroundColor = `rgb(217, 217, 217)`;
  } else {
    nav.style.backgroundColor = `rgb(248, 248, 248)`; //Jasny
    navUl.style.backgroundColor = `rgb(248, 248, 248)`;
  }
};

window.addEventListener('scroll', boldScroll);
